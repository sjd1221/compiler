import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Compiler implements ActionListener
{
	
	JTextArea textarea;
	
	public static void main(String[] args)
	{
		
		Compiler compiler = new Compiler();
		compiler.frame();
		
	}
	
	public void frame()
	{
		
		textarea = new JTextArea();
		textarea.setBounds(0,0,600,600);
		
		JScrollPane tsp = new JScrollPane(textarea);
		tsp.setBounds(0,0,600,600);
		
		JButton btn = new JButton("Run");
		btn.setBounds(0,600,600,50);
		btn.addActionListener(this);
    	
    	JFrame frame = new JFrame();
    	frame.add(tsp); frame.add(btn);
    	frame.setSize(620,700);
        frame.getContentPane().setBackground(Color.black);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		
		int sindex , eindex , i = 0;
		String text = textarea.getText();
		ArrayList<String> quotes = new ArrayList<String>();
		
		sindex = text.indexOf("\"");
		while(sindex != -1)
		{
			
			eindex = eind(sindex , text);
			quotes.add(text.substring(sindex , eindex + 1));
			text = text.substring(0 , sindex) + '#' + text.substring(eindex + 1);
			sindex = text.indexOf("\"");
			
		}
		
		sindex = text.indexOf("Begir");
		while(sindex != -1)
		{
			
			sindex = text.indexOf("," , sindex);
			text = text.substring(0 , sindex + 1) + '&' + text.substring(sindex + 1);
			sindex = text.indexOf("Begir" , sindex + 1);
			
		}
		
		text = text.replace("Benevis" , "printf");
		text = text.replace("^" , ";");
		text = text.replace("Begir" , "scanf");
		text = text.replace("agar" , "if");
		text = text.replace("{" , "(");
		text = text.replace("}" , ")");
		text = text.replace("ta" , "while");
		text = text.replace("[" , "{");
		text = text.replace("]" , "}");
		text = text.replace("&BM" , ">=");
		text = text.replace("&B" , ">");
		text = text.replace("&KM" , "<=");
		text = text.replace("&K" , "<");
		text = text.replace("&MM" , "==");
		text = text.replace("&NM" , "!=");
		text = text.replace("Jam" , "+");
		text = text.replace("YekiBala" , "++");
		text = text.replace("Kam" , "-");
		text = text.replace("YekiPain" , "--");
		text = text.replace("Zarb" , "*");
		text = text.replace("Tagsim" , "/");
		text = text.replace("Bagimonde" , "%");
		text = text.replace("Sahih" , "int");
		text = text.replace("Ashari" , "float");
		text = text.replace("Harf" , "char");
		
		sindex = text.indexOf("#");
		while(sindex != -1)
		{
			
			text = text.substring(0 , sindex) + quotes.get(i) + text.substring(sindex + 1);
			sindex = text.indexOf("#" , sindex + quotes.get(i).length());
			i++;
			
		}
		
		text = "#include <stdio.h>\nvoid main() {\n" + text + "\n}";
		
		textarea.setText(null);
		textarea.setText(text);
		
	}
	
	private int eind(int sindex, String text)
	{
		
		int eindex = text.indexOf("\"" , sindex + 1);
		
		if(text.charAt(eindex - 1) != '\\')
			return eindex;
		
		else
			return eind(eindex , text);
		
	}
	
}